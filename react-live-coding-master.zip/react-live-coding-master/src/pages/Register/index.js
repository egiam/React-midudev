import React from 'react'
import Register from 'components/Register'

export default function RegisterPage () {
  return <>
    <h2>Register</h2>
    <Register />
  </>
}