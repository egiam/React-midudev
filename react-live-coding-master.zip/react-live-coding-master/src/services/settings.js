export const API_KEY = 'dIJrma20pSU6ymMwWnDbiaT7NFHeAGVa'

export const API_URL = 'https://api.giphy.com/v1'