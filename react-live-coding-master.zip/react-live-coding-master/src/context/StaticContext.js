import React from 'react'

const Context = React.createContext({
  name: 'esto-es-sin-provider',
  suscribeteAlCanal: true
})

export default Context