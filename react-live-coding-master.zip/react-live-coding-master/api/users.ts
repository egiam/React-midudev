export interface User {
  username: String;
  password: String
}

export const users: User[] = [
  {
    username: "midudev",
    password: "$2a$10$K8ZpdrjwzUWSTmtyM.SAHewu7Zxpq3kUXnv/DPZSM8k.DSrmSekxi"
  }
]