# Api de Usuarios con Deno 🦕

Para ejecutar en local esta API necesitas tener instada la última versión de Deno y ejecutar dentro de la carpeta `/api`:

```js
deno run --allow-net=:8080 --allow-read --allow-env server.ts --port=8080
```