export const favs: any = {
  'midudev': []
}